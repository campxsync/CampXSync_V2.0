-- =============================================================================
-- OPTIONAL A: align acd.course_versions and acd.course_prerequisites with acd01.*
-- NOT in supabase/migrations on purpose. The 2026-10-26 audit flagged only acd.courses,
-- but the live catalog shows these two child tables (used by the course-management
-- service) ALSO check acd03.*. If acd.courses is wrong, these almost certainly are too:
-- an acd01-only user could create a course but not its versions/prerequisites.
-- Apply only after confirming the same intent as 20261027000100.
-- To enable: copy to supabase/migrations/20261027000150_align_course_child_tables_rls.sql
-- (must sort AFTER 20261027000100). Same fail-closed pre/postconditions. Idempotent.
-- NOTE: curricula, curriculum_versions, curriculum_subjects and subject_course_map also
-- use acd03.*; those look like genuine Subject/Curriculum-module tables and are NOT touched.
-- Rollback: supabase/rollbacks/OPT_A_rollback.sql
-- =============================================================================
begin;

do $$
declare v_missing text; v_t text;
begin
  foreach v_t in array array['course_versions', 'course_prerequisites'] loop
    if to_regclass('acd.' || v_t) is null then
      raise exception 'precondition failed: table acd.% not found', v_t;
    end if;
    if (select count(*) from pg_policies
         where schemaname = 'acd' and tablename = v_t
           and policyname in (v_t || '_select', v_t || '_insert', v_t || '_update', v_t || '_delete')) <> 4 then
      raise exception 'precondition failed: acd.% does not have exactly the 4 standard policies (_select/_insert/_update/_delete)', v_t;
    end if;
  end loop;
  if to_regprocedure('core.current_tenant_id()') is null
     or to_regprocedure('iam.perm_all(text)') is null
     or to_regprocedure('iam.perm_department_ids(text)') is null
     or to_regprocedure('iam.has_permission(text)') is null then
    raise exception 'precondition failed: RLS helper functions (core.current_tenant_id, iam.perm_all, iam.perm_department_ids, iam.has_permission) are missing';
  end if;
  if to_regprocedure('core.courses_in_scope(text,boolean)') is null then raise exception 'precondition failed: helper function core.courses_in_scope(text,boolean) is missing'; end if;
  select string_agg(c, ', ') into v_missing
    from unnest(array['acd01.view','acd01.write','acd01.manage']) c
   where not exists (select 1 from iam.permissions p where p.code = c and p.deleted_at is null);
  if v_missing is not null then
    raise exception 'precondition failed: permission codes missing from iam.permissions: %', v_missing;
  end if;
end $$;

drop policy if exists course_versions_select on acd.course_versions;
create policy course_versions_select on acd.course_versions
  as permissive for select to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.view'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd01.view'::text, false) AS courses_in_scope)))));

drop policy if exists course_versions_insert on acd.course_versions;
create policy course_versions_insert on acd.course_versions
  as permissive for insert to authenticated
  with check (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.write'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd01.write'::text, true) AS courses_in_scope)))));

drop policy if exists course_versions_update on acd.course_versions;
create policy course_versions_update on acd.course_versions
  as permissive for update to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.write'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd01.write'::text, true) AS courses_in_scope)))))
  with check (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.write'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd01.write'::text, true) AS courses_in_scope)))));

drop policy if exists course_versions_delete on acd.course_versions;
create policy course_versions_delete on acd.course_versions
  as permissive for delete to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.manage'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd01.manage'::text, true) AS courses_in_scope)))));

drop policy if exists course_prerequisites_select on acd.course_prerequisites;
create policy course_prerequisites_select on acd.course_prerequisites
  as permissive for select to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.view'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd01.view'::text, false) AS courses_in_scope)))));

drop policy if exists course_prerequisites_insert on acd.course_prerequisites;
create policy course_prerequisites_insert on acd.course_prerequisites
  as permissive for insert to authenticated
  with check (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.write'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd01.write'::text, true) AS courses_in_scope)))));

drop policy if exists course_prerequisites_update on acd.course_prerequisites;
create policy course_prerequisites_update on acd.course_prerequisites
  as permissive for update to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.write'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd01.write'::text, true) AS courses_in_scope)))))
  with check (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.write'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd01.write'::text, true) AS courses_in_scope)))));

drop policy if exists course_prerequisites_delete on acd.course_prerequisites;
create policy course_prerequisites_delete on acd.course_prerequisites
  as permissive for delete to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.manage'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd01.manage'::text, true) AS courses_in_scope)))));

do $$
declare v_t text; v_old int; v_new int;
begin
  foreach v_t in array array['course_versions', 'course_prerequisites'] loop
    select count(*) filter (where coalesce(qual,'') || coalesce(with_check,'') like '%acd03.%'),
           count(*) filter (where coalesce(qual,'') || coalesce(with_check,'') like '%acd01.%')
      into v_old, v_new
      from pg_policies where schemaname = 'acd' and tablename = v_t;
    if v_old <> 0 or v_new <> 4 then
      raise exception 'postcondition failed on acd.%: acd03 refs=%, acd01 refs=% (expected 0 and 4)', v_t, v_old, v_new;
    end if;
  end loop;
end $$;

commit;
