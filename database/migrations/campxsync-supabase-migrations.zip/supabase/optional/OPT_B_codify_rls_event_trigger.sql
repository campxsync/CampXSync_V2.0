-- =============================================================================
-- OPTIONAL B: codify the untracked live event trigger found on dev (audit addendum 2026-10-26)
-- NOT in supabase/migrations on purpose: it is a decision, not a fix.
--
-- What dev has: event trigger enable_rls_on_new_tables fires on every CREATE TABLE and enables
-- RLS for tables in schemas audit, cam, hrm, lms. It has no script in the repo. Migration
-- 20261027000200 already makes sys.ensure_partitions enable RLS itself, so partitions no longer
-- depend on this trigger. Keeping the trigger only adds a safety net for any other new table
-- created in those four schemas.
--   * Apply this if you want fresh/staging/prod databases to behave like dev.
--   * Skip it (and consider dropping the trigger on dev) if you prefer explicit RLS in migrations.
-- Event triggers need elevated privilege; on Supabase hosted the postgres role created it on dev.
-- To enable: copy to supabase/migrations/20261027000250_codify_rls_event_trigger.sql
-- Idempotent. Rollback: supabase/rollbacks/OPT_B_rollback.sql
-- =============================================================================
begin;

create or replace function sys.enable_rls_on_new_tables()
 returns event_trigger
 language plpgsql
as $function$
declare r record;
begin
  for r in
    select objid::regclass as tbl
    from pg_event_trigger_ddl_commands()
    where command_tag = 'CREATE TABLE'
      and schema_name in ('audit','cam','hrm','lms')
  loop
    execute format('alter table %s enable row level security', r.tbl);
  end loop;
end $function$;

do $$
begin
  if not exists (select 1 from pg_event_trigger where evtname = 'enable_rls_on_new_tables') then
    create event trigger enable_rls_on_new_tables
      on ddl_command_end
      when tag in ('CREATE TABLE')
      execute function sys.enable_rls_on_new_tables();
  end if;
end $$;

commit;
