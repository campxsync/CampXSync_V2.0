-- =============================================================================
-- ROLLBACK for 20261027000100_fix_acd_courses_rls_permission_codes.sql
-- Restores the pre-fix acd.courses policies (acd03.*), exactly as captured live on
-- 2026-10-26. Run manually (SQL editor / psql); the Supabase CLI has no down-migrations.
-- Afterwards: supabase migration repair 20261027000100 --status reverted
-- =============================================================================
begin;

drop policy if exists courses_select on acd.courses;
create policy courses_select on acd.courses
  as permissive for select to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.view'::text) AS perm_all) OR ((department_id IN ( SELECT unnest(iam.perm_department_ids('acd03.view'::text)) AS unnest)) OR ((NOT false) AND (department_id IS NULL) AND ( SELECT iam.has_permission('acd03.view'::text) AS has_permission))))));

drop policy if exists courses_insert on acd.courses;
create policy courses_insert on acd.courses
  as permissive for insert to authenticated
  with check (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.write'::text) AS perm_all) OR ((department_id IN ( SELECT unnest(iam.perm_department_ids('acd03.write'::text)) AS unnest)) OR ((NOT true) AND (department_id IS NULL) AND ( SELECT iam.has_permission('acd03.write'::text) AS has_permission))))));

drop policy if exists courses_update on acd.courses;
create policy courses_update on acd.courses
  as permissive for update to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.write'::text) AS perm_all) OR ((department_id IN ( SELECT unnest(iam.perm_department_ids('acd03.write'::text)) AS unnest)) OR ((NOT true) AND (department_id IS NULL) AND ( SELECT iam.has_permission('acd03.write'::text) AS has_permission))))))
  with check (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.write'::text) AS perm_all) OR ((department_id IN ( SELECT unnest(iam.perm_department_ids('acd03.write'::text)) AS unnest)) OR ((NOT true) AND (department_id IS NULL) AND ( SELECT iam.has_permission('acd03.write'::text) AS has_permission))))));

drop policy if exists courses_delete on acd.courses;
create policy courses_delete on acd.courses
  as permissive for delete to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.manage'::text) AS perm_all) OR ((department_id IN ( SELECT unnest(iam.perm_department_ids('acd03.manage'::text)) AS unnest)) OR ((NOT true) AND (department_id IS NULL) AND ( SELECT iam.has_permission('acd03.manage'::text) AS has_permission))))));

commit;
