-- ROLLBACK for OPTIONAL A: restores acd03.* policies on course_versions and course_prerequisites
-- (as captured live 2026-10-26). Run manually; then: supabase migration repair <version> --status reverted
begin;

drop policy if exists course_versions_select on acd.course_versions;
create policy course_versions_select on acd.course_versions
  as permissive for select to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.view'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd03.view'::text, false) AS courses_in_scope)))));

drop policy if exists course_versions_insert on acd.course_versions;
create policy course_versions_insert on acd.course_versions
  as permissive for insert to authenticated
  with check (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.write'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd03.write'::text, true) AS courses_in_scope)))));

drop policy if exists course_versions_update on acd.course_versions;
create policy course_versions_update on acd.course_versions
  as permissive for update to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.write'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd03.write'::text, true) AS courses_in_scope)))))
  with check (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.write'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd03.write'::text, true) AS courses_in_scope)))));

drop policy if exists course_versions_delete on acd.course_versions;
create policy course_versions_delete on acd.course_versions
  as permissive for delete to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.manage'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd03.manage'::text, true) AS courses_in_scope)))));

drop policy if exists course_prerequisites_select on acd.course_prerequisites;
create policy course_prerequisites_select on acd.course_prerequisites
  as permissive for select to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.view'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd03.view'::text, false) AS courses_in_scope)))));

drop policy if exists course_prerequisites_insert on acd.course_prerequisites;
create policy course_prerequisites_insert on acd.course_prerequisites
  as permissive for insert to authenticated
  with check (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.write'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd03.write'::text, true) AS courses_in_scope)))));

drop policy if exists course_prerequisites_update on acd.course_prerequisites;
create policy course_prerequisites_update on acd.course_prerequisites
  as permissive for update to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.write'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd03.write'::text, true) AS courses_in_scope)))))
  with check (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.write'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd03.write'::text, true) AS courses_in_scope)))));

drop policy if exists course_prerequisites_delete on acd.course_prerequisites;
create policy course_prerequisites_delete on acd.course_prerequisites
  as permissive for delete to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd03.manage'::text) AS perm_all) OR (course_id IN ( SELECT core.courses_in_scope('acd03.manage'::text, true) AS courses_in_scope)))));

commit;
