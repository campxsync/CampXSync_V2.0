-- ROLLBACK for OPTIONAL B: removes the event trigger and its function.
-- WARNING: only run this on environments where 20261027000200 is applied; otherwise new partitions
-- would no longer get RLS enabled automatically.
begin;
drop event trigger if exists enable_rls_on_new_tables;
drop function if exists sys.enable_rls_on_new_tables();
commit;
