-- ROLLBACK for 20261027000300_extend_partitions_and_schedule_maintenance.sql
-- 1. Unschedules the cron job (the pg_cron extension itself is left installed).
-- 2. Drops ONLY future monthly partitions beyond 2027-01 that are EMPTY. Non-empty ones are kept
--    and reported. Partitions are harmless if left in place, so skipping step 2 is fine.
-- Run manually; then: supabase migration repair 20261027000300 --status reverted
begin;

do $$
begin
  if to_regclass('cron.job') is not null then
    perform cron.unschedule(jobid) from cron.job where jobname = 'campx-ensure-partitions';
  end if;
end $$;

do $$
declare r record; v_has boolean;
begin
  for r in
    select n.nspname, c.relname
      from pg_class c join pg_namespace n on n.oid = c.relnamespace
     where c.relispartition and c.relkind = 'r'
       and n.nspname in ('audit','cam','hrm','lms')
       and c.relname ~ '_p[0-9]{6}$'
       and substring(c.relname from '_p([0-9]{6})$') > '202701'
  loop
    execute format('select exists (select 1 from %I.%I)', r.nspname, r.relname) into v_has;
    if v_has then
      raise notice 'kept non-empty partition %.%', r.nspname, r.relname;
    else
      execute format('drop table %I.%I', r.nspname, r.relname);
    end if;
  end loop;
end $$;

commit;
