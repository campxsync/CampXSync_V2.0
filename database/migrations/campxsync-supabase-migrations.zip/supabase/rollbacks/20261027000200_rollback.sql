-- ROLLBACK for 20261027000200_harden_sys_ensure_partitions.sql
-- Restores the live definition captured 2026-10-26 (no RLS statement, no argument guard).
-- EXECUTE is re-granted to PUBLIC (PostgreSQL's default for functions). The original ACL was not
-- captured in the audit; adjust if your environment had a different one.
-- Run manually; then: supabase migration repair 20261027000200 --status reverted
begin;

create or replace function sys.ensure_partitions(p_months_ahead integer default 3)
 returns void
 language plpgsql
 security definer
 set search_path to ''
as $function$
declare t text; m date; nm text; i int;
begin
  foreach t in array array['audit.change_log', 'audit.events', 'audit.access_events', 'lms.progress_events', 'hrm.attendance_punches', 'cam.delivery_events'] loop
    for i in 0..p_months_ahead loop
      m  := (date_trunc('month', now() at time zone 'UTC') + make_interval(months => i))::date;
      nm := format('%s_p%s', t, to_char(m, 'YYYYMM'));
      if to_regclass(nm) is null then
        execute format('create table %s partition of %s for values from (%L) to (%L)', nm, t,
                       (m::timestamp at time zone 'UTC'), ((m + interval '1 month')::timestamp at time zone 'UTC'));
        execute format('revoke all on %s from anon, authenticated', nm);   -- RLS lives on the parent; never expose partitions directly
      end if;
    end loop;
  end loop;
end $function$;

grant execute on function sys.ensure_partitions(integer) to public;

commit;
