-- =============================================================================
-- 20261027000100_fix_acd_courses_rls_permission_codes.sql
-- Supabase CLI migration (forward). Rollback: supabase/rollbacks/20261027000100_rollback.sql
--
-- WHAT: acd.courses RLS policies currently check permission codes acd03.view /
--       acd03.write / acd03.manage. This switches them to acd01.view / .write /
--       .manage. Nothing else changes: the policy expressions below are the live
--       catalog expressions (audit 2026-10-26, catalog-dump/policies.csv) with ONLY
--       the permission-code prefix changed.
-- DECISION BEFORE APPLYING: confirm acd01.* is the intended code for course
--       management (run supabase/verify/00_preflight_readonly.sql, section 3, and
--       check what the course-management service itself checks).
-- SAFETY: fail-closed. Aborts (whole file rolls back) if the table, the 4 standard
--       policies, the RLS helper functions, or the acd01.* permission codes are missing.
-- Idempotent: safe to re-run (DROP POLICY IF EXISTS + CREATE).
-- =============================================================================
begin;

do $$
declare v_missing text; v_t text;
begin
  foreach v_t in array array['courses'] loop
    if to_regclass('acd.' || v_t) is null then
      raise exception 'precondition failed: table acd.% not found', v_t;
    end if;
    if (select count(*) from pg_policies
         where schemaname = 'acd' and tablename = v_t
           and policyname in (v_t || '_select', v_t || '_insert', v_t || '_update', v_t || '_delete')) <> 4 then
      raise exception 'precondition failed: acd.% does not have exactly the 4 standard policies (_select/_insert/_update/_delete)', v_t;
    end if;
  end loop;
  if to_regprocedure('core.current_tenant_id()') is null
     or to_regprocedure('iam.perm_all(text)') is null
     or to_regprocedure('iam.perm_department_ids(text)') is null
     or to_regprocedure('iam.has_permission(text)') is null then
    raise exception 'precondition failed: RLS helper functions (core.current_tenant_id, iam.perm_all, iam.perm_department_ids, iam.has_permission) are missing';
  end if;
  select string_agg(c, ', ') into v_missing
    from unnest(array['acd01.view','acd01.write','acd01.manage']) c
   where not exists (select 1 from iam.permissions p where p.code = c and p.deleted_at is null);
  if v_missing is not null then
    raise exception 'precondition failed: permission codes missing from iam.permissions: %', v_missing;
  end if;
end $$;

drop policy if exists courses_select on acd.courses;
create policy courses_select on acd.courses
  as permissive for select to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.view'::text) AS perm_all) OR ((department_id IN ( SELECT unnest(iam.perm_department_ids('acd01.view'::text)) AS unnest)) OR ((NOT false) AND (department_id IS NULL) AND ( SELECT iam.has_permission('acd01.view'::text) AS has_permission))))));

drop policy if exists courses_insert on acd.courses;
create policy courses_insert on acd.courses
  as permissive for insert to authenticated
  with check (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.write'::text) AS perm_all) OR ((department_id IN ( SELECT unnest(iam.perm_department_ids('acd01.write'::text)) AS unnest)) OR ((NOT true) AND (department_id IS NULL) AND ( SELECT iam.has_permission('acd01.write'::text) AS has_permission))))));

drop policy if exists courses_update on acd.courses;
create policy courses_update on acd.courses
  as permissive for update to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.write'::text) AS perm_all) OR ((department_id IN ( SELECT unnest(iam.perm_department_ids('acd01.write'::text)) AS unnest)) OR ((NOT true) AND (department_id IS NULL) AND ( SELECT iam.has_permission('acd01.write'::text) AS has_permission))))))
  with check (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.write'::text) AS perm_all) OR ((department_id IN ( SELECT unnest(iam.perm_department_ids('acd01.write'::text)) AS unnest)) OR ((NOT true) AND (department_id IS NULL) AND ( SELECT iam.has_permission('acd01.write'::text) AS has_permission))))));

drop policy if exists courses_delete on acd.courses;
create policy courses_delete on acd.courses
  as permissive for delete to authenticated
  using (((tenant_id = ( SELECT core.current_tenant_id() AS current_tenant_id)) AND (( SELECT iam.perm_all('acd01.manage'::text) AS perm_all) OR ((department_id IN ( SELECT unnest(iam.perm_department_ids('acd01.manage'::text)) AS unnest)) OR ((NOT true) AND (department_id IS NULL) AND ( SELECT iam.has_permission('acd01.manage'::text) AS has_permission))))));

do $$
declare v_t text; v_old int; v_new int;
begin
  foreach v_t in array array['courses'] loop
    select count(*) filter (where coalesce(qual,'') || coalesce(with_check,'') like '%acd03.%'),
           count(*) filter (where coalesce(qual,'') || coalesce(with_check,'') like '%acd01.%')
      into v_old, v_new
      from pg_policies where schemaname = 'acd' and tablename = v_t;
    if v_old <> 0 or v_new <> 4 then
      raise exception 'postcondition failed on acd.%: acd03 refs=%, acd01 refs=% (expected 0 and 4)', v_t, v_old, v_new;
    end if;
  end loop;
end $$;

commit;
