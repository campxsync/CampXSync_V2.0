-- =============================================================================
-- 20261027000200_harden_sys_ensure_partitions.sql
-- Supabase CLI migration (forward). Rollback: supabase/rollbacks/20261027000200_rollback.sql
--
-- WHAT:
--  1. sys.ensure_partitions() now ENABLEs ROW LEVEL SECURITY on every monthly
--     partition it creates or finds, and on each _default partition (previously it only
--     REVOKEd anon/authenticated on new partitions and never touched RLS).
--     This is the fix proposed by V20261020_01 step 5, which was never applied.
--     Dev currently gets RLS on new partitions only because of an UNTRACKED event
--     trigger (see optional/OPT_B). Staging/prod/fresh databases would not.
--  2. Adds an argument guard (0..24 months) so a typo cannot create hundreds of tables.
--  3. Revokes EXECUTE on this SECURITY DEFINER DDL function from PUBLIC/anon/authenticated.
--     (pg_cron runs it as postgres, which owns it.) If any service legitimately calls it
--     as campx_app_server, grant it back explicitly.
-- Everything else is identical to the live definition captured 2026-10-26.
-- SAFETY: fail-closed on missing function/parents. Idempotent.
-- =============================================================================
begin;

do $$
declare t text;
begin
  if to_regprocedure('sys.ensure_partitions(integer)') is null then
    raise exception 'precondition failed: sys.ensure_partitions(integer) not found';
  end if;
  foreach t in array array['audit.change_log','audit.events','audit.access_events',
                           'lms.progress_events','hrm.attendance_punches','cam.delivery_events'] loop
    if not exists (select 1 from pg_class where oid = to_regclass(t) and relkind = 'p') then
      raise exception 'precondition failed: % is not a partitioned table', t;
    end if;
  end loop;
end $$;

create or replace function sys.ensure_partitions(p_months_ahead integer default 3)
 returns void
 language plpgsql
 security definer
 set search_path to ''
as $function$
declare t text; m date; nm text; i int;
begin
  if p_months_ahead is null or p_months_ahead < 0 or p_months_ahead > 24 then
    raise exception 'p_months_ahead must be between 0 and 24 (got %)', p_months_ahead;
  end if;
  foreach t in array array['audit.change_log', 'audit.events', 'audit.access_events', 'lms.progress_events', 'hrm.attendance_punches', 'cam.delivery_events'] loop
    for i in 0..p_months_ahead loop
      m  := (date_trunc('month', now() at time zone 'UTC') + make_interval(months => i))::date;
      nm := format('%s_p%s', t, to_char(m, 'YYYYMM'));
      if to_regclass(nm) is null then
        execute format('create table %s partition of %s for values from (%L) to (%L)', nm, t,
                       (m::timestamp at time zone 'UTC'), ((m + interval '1 month')::timestamp at time zone 'UTC'));
        execute format('revoke all on %s from anon, authenticated', nm);   -- never expose partitions directly
      end if;
      execute format('alter table %s enable row level security', nm);      -- idempotent; also heals older partitions
    end loop;
    if to_regclass(t || '_default') is not null then                       -- the DEFAULT partition too
      execute format('alter table %s_default enable row level security', t);
    end if;
  end loop;
end $function$;

revoke all on function sys.ensure_partitions(integer) from public, anon, authenticated;

do $$
begin
  if position('enable row level security' in pg_get_functiondef('sys.ensure_partitions(integer)'::regprocedure)) = 0 then
    raise exception 'postcondition failed: ensure_partitions does not enable RLS';
  end if;
end $$;

commit;
