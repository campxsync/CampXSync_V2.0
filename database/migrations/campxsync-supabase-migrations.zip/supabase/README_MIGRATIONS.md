# CampXSync: Supabase CLI migrations (forward-fix set)

Not applied anywhere. Written for later use. Only `supabase/migrations/` is read by the CLI;
`optional/`, `rollbacks/` and `verify/` are ignored by it.

## What is here
| File | Auto-applied | Purpose |
|---|---|---|
| migrations/20261027000100_fix_acd_courses_rls_permission_codes.sql | yes | `acd.courses` RLS: `acd03.*` -> `acd01.*` (live expressions, prefix swap only) |
| migrations/20261027000200_harden_sys_ensure_partitions.sql | yes | `ensure_partitions` enables RLS on monthly AND default partitions; argument guard; revoke EXECUTE from PUBLIC/anon/authenticated |
| migrations/20261027000300_extend_partitions_and_schedule_maintenance.sql | yes | Aborts if any default partition has rows; creates partitions 12 months ahead; schedules monthly job via pg_cron |
| optional/OPT_A_align_course_child_tables_rls.sql | no | Same acd03 -> acd01 swap for `course_versions`, `course_prerequisites` (audit missed these) |
| optional/OPT_B_codify_rls_event_trigger.sql | no | Codifies the untracked dev event trigger `enable_rls_on_new_tables` |
| rollbacks/* | no | Manual undo for each of the above |
| verify/00_preflight_readonly.sql, 01_postflight_readonly.sql | no | Read-only checks to run before / after |

Every migration is fail-closed (pre/postconditions inside one transaction) and idempotent.

## Before applying to any environment
1. Run `verify/00_preflight_readonly.sql` in the SQL editor. It is read-only (only row COUNTS on the 6 default partitions).
2. **Decide the acd01 question.** Section 3 of the preflight shows what `acd01.*` and `acd03.*` mean and which roles hold them.
   `acd01.*` is also used by the academic-calendar tables and `course_program_map`, so confirm it is the code the
   course-management service checks before applying migration 100. If you would rather use your own
   `V20261011_01`, drop my file 100; do not apply both.
3. Staging (`kpwdvvcschankgggitnj`) has never been audited. Preflight section 7 shows whether it has the earlier
   wave objects (Option C function, `campx_app_server`, outbox policies). If those are missing, staging needs more than this set.

## Apply (per environment: dev -> staging -> prod)
```
supabase link --project-ref <ref>
supabase migration list
supabase db push --dry-run        # shows what would run, runs nothing
supabase db push
```
Use the direct connection or the session-mode pooler (port 5432), not the 6543 transaction pooler.
Then run `verify/01_postflight_readonly.sql`: every row should be PASS (the cron row is SKIP if pg_cron is absent).
On an environment with no history, the first `db push` creates `supabase_migrations.schema_migrations` and records only these migrations.

## Optional files
Copy into `supabase/migrations/` with a timestamp that sorts after 20261027000100, e.g. `20261027000150_...` (A) and
`20261027000250_...` (B). Decide B knowingly: migration 200 already makes partitions independent of the trigger.

## Rolling back
The CLI has no down-migrations. Run the matching file from `rollbacks/` manually, then:
`supabase migration repair <version> --status reverted`.

## Baseline (not included, on purpose)
Task F (scratch rebuild) was not run, so a baseline cannot be verified. The audit's `schema_only.sql` is hand-synthesized and
must NOT be used as one: it declares every primary key twice and re-creates 828 constraint-backed indexes, so it will not load.
When you can: take a real `pg_dump --schema-only` (or `supabase db dump`), name it with a timestamp earlier than 20261027000100, and on each
existing environment run `supabase migration repair <that version> --status applied` BEFORE the next `db push`.
Until then, a brand-new database is not reproducible from this repo with verified results.

## What was tested (and what was not)
Tested on a throwaway PostgreSQL 16 in a sandbox, against stub schemas that mimic dev (6 partitioned parents with default and
monthly children, the original acd03 policies, stub RLS helper functions): forward apply, re-apply, rollbacks, argument guard,
EXECUTE revoke, four fail-closed cases, event trigger, and both verify files.
NOT tested: the Supabase CLI itself, any CampXSync database, the pg_cron path (absent in the sandbox; only the "not available"
warning branch ran), and real data volumes.
