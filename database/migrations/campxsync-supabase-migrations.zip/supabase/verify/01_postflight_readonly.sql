-- =============================================================================
-- 01_postflight_readonly.sql  --  run after `supabase db push`. Read-only. Every row should say PASS.
-- =============================================================================
with parents(p) as (values ('audit.change_log'),('audit.events'),('audit.access_events'),
                           ('lms.progress_events'),('hrm.attendance_punches'),('cam.delivery_events'))
select 'acd.courses uses only acd01.* (4 policies)' as check_name,
       case when count(*) filter (where (coalesce(qual,'')||coalesce(with_check,'')) ~ 'acd03\.') = 0
             and count(*) filter (where (coalesce(qual,'')||coalesce(with_check,'')) ~ 'acd01\.') = 4
            then 'PASS' else 'FAIL' end as result
from pg_policies where schemaname = 'acd' and tablename = 'courses'
union all
select 'sys.ensure_partitions enables RLS',
       case when position('enable row level security' in pg_get_functiondef('sys.ensure_partitions(integer)'::regprocedure)) > 0 then 'PASS' else 'FAIL' end
union all
select 'anon/authenticated cannot execute sys.ensure_partitions',
       case when not has_function_privilege('anon','sys.ensure_partitions(integer)','execute')
             and not has_function_privilege('authenticated','sys.ensure_partitions(integer)','execute') then 'PASS' else 'FAIL' end
union all
select 'partition exists 12 months ahead: ' || p,
       case when to_regclass(p || '_p' || to_char((date_trunc('month', now() at time zone 'UTC') + interval '12 months')::date, 'YYYYMM')) is not null then 'PASS' else 'FAIL' end
from parents
union all
select 'every partition in audit/cam/hrm/lms has RLS enabled',
       case when count(*) filter (where not c.relrowsecurity) = 0 then 'PASS' else 'FAIL (' || count(*) filter (where not c.relrowsecurity) || ' without RLS)' end
from pg_class c join pg_namespace n on n.oid = c.relnamespace
where c.relispartition and n.nspname in ('audit','cam','hrm','lms')
union all
select 'monthly maintenance job scheduled (needs pg_cron)',
       case when to_regclass('cron.job') is null then 'SKIP (pg_cron not installed: schedule externally)'
            else case when (xpath('/row/c/text()', query_to_xml(
                     'select count(*) as c from cron.job where jobname = ''campx-ensure-partitions''', false, true, '')))[1]::text = '1'
                      then 'PASS' else 'FAIL' end end;
-- If you applied the optional migrations also run:
--   select tablename, count(*) filter (where (coalesce(qual,'')||coalesce(with_check,'')) ~ 'acd01\.') as acd01_policies
--   from pg_policies where schemaname='acd' and tablename in ('course_versions','course_prerequisites') group by 1;  -- expect 4 each
