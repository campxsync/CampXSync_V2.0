-- =============================================================================
-- 00_preflight_readonly.sql  --  run in the Supabase SQL editor on EACH environment BEFORE db push
-- 100% read-only (SELECTs only). The only table data touched is a row COUNT on the six
-- _default partitions (section 5). Run section by section and read the results.
-- =============================================================================

-- 1. Which environment is this, and does it already have CLI migration history?
select current_database() as db, current_user as usr;
select id, code, name, status from core.tenants order by created_at;      -- expect DEV_TEST_TENANT on dev
select to_regclass('supabase_migrations.schema_migrations') as migration_history_table;
-- if not null, also run:  select version, name from supabase_migrations.schema_migrations order by version;

-- 2. Which permission codes do the course-related tables check today?
select tablename, policyname, cmd,
       (coalesce(qual,'') || coalesce(with_check,'')) ~ 'acd03\.' as uses_acd03,
       (coalesce(qual,'') || coalesce(with_check,'')) ~ 'acd01\.' as uses_acd01
from pg_policies
where schemaname = 'acd'
  and tablename in ('courses','course_versions','course_prerequisites','course_program_map')
order by tablename, cmd;

-- 3. DECISION INPUT for migration 20261027000100: what do acd01.* and acd03.* actually mean,
--    and which system roles hold them? Compare with what the course-management service checks.
select code, module, resource, action, description
from iam.permissions
where code like 'acd01.%' or code like 'acd03.%'
order by code;

select r.code as role_code, p.code as permission, count(distinct r.tenant_id) as tenants
from iam.role_permissions rp
join iam.roles r        on r.id = rp.role_id
join iam.permissions p  on p.id = rp.permission_id
where (p.code like 'acd01.%' or p.code like 'acd03.%')
  and r.is_system
group by r.code, p.code
order by r.code, p.code;

-- 4. Partition maintenance function: does it already enable RLS? Who may execute it?
select position('enable row level security' in pg_get_functiondef('sys.ensure_partitions(integer)'::regprocedure)) > 0 as has_rls_clause,
       proacl
from pg_proc where oid = 'sys.ensure_partitions(integer)'::regprocedure;

-- 5. Partition state. Default partitions MUST be empty for migration 20261027000300.
select parent.oid::regclass as parent, child.oid::regclass as child,
       pg_get_expr(child.relpartbound, child.oid) as bound, child.relrowsecurity as rls
from pg_inherits i
join pg_class parent on parent.oid = i.inhparent
join pg_class child  on child.oid  = i.inhrelid
where parent.oid in ('audit.change_log'::regclass,'audit.events'::regclass,'audit.access_events'::regclass,
                     'lms.progress_events'::regclass,'hrm.attendance_punches'::regclass,'cam.delivery_events'::regclass)
order by 1, 3;

select 'audit.change_log_default' as default_partition, count(*) as row_count from audit.change_log_default
union all select 'audit.events_default',          count(*) from audit.events_default
union all select 'audit.access_events_default',   count(*) from audit.access_events_default
union all select 'lms.progress_events_default',   count(*) from lms.progress_events_default
union all select 'hrm.attendance_punches_default',count(*) from hrm.attendance_punches_default
union all select 'cam.delivery_events_default',   count(*) from cam.delivery_events_default;

-- 6. Scheduler and event-trigger state
select name, default_version, installed_version from pg_available_extensions where name in ('pg_cron','pg_net');
-- only if pg_cron is installed:  select jobid, jobname, schedule, command, active from cron.job;
select evtname, evtevent, evtenabled, evtfoid::regproc as function from pg_event_trigger;

-- 7. Objects earlier waves added; staging may be missing some of them (informational)
select to_regprocedure('core.is_active_course_in_tenant(uuid)') is not null as option_c_function_present,
       exists (select 1 from pg_roles where rolname = 'campx_app_server')   as app_role_present,
       (select count(*) from pg_policies where schemaname = 'sys' and tablename = 'outbox_events') as outbox_policies_expected_4;
